#include <kipr/botball.h>
void backward()
{
        create_drive_direct(-100,-100);
}
void left()
{
        create_drive_direct(100,-100);
        msleep(1550);
}
void forward()
    // 1000 msleep = 4.5 inches
	// 4888.8 (with a bar) = 21 inches
    // 13333.3 (with a bar) = 60 inches
{
        create_drive_direct(100,100);
}
void speedburst()
{	create_drive_direct(-250,-250);
 msleep(4000);
}
void right()
{
        create_drive_direct(100,0);
        msleep(3000);
}
void rightshort()
{
    create_drive_direct(0,-100);
		msleep(500);
}
void leftshort()
{
	create_drive_direct(-100,0);
    	msleep(500);
        }
void FollowTheLine()
{
    set_create_distance(0);
    int create_distance = 0;
    while(create_distance >= -1500){
        //Could be -1600             ^
        create_distance = get_create_distance();
         printf("%i", create_distance);
        create_drive_direct(-200,-200);
        msleep(150);   
        if(analog(3) > 4000){
            rightshort();
        }
        if(analog(5) > 3000){
            leftshort();
        }
  	}
}

int main()
{
    //wait_for_light(1);
    shut_down_in(120);
    create_connect();
    create_full();
    backward();
    msleep(4000);
    left();
    backward();
    msleep(4000);
    left();
    //Do not need speedburst. Disabled the safety instead.
    //speedburst();
    FollowTheLine();
    //Turn the Roomba safety back on.
    create_safe();
    left();
    backward();
    msleep(4000);
    left();
    backward();
    msleep(6000);
    forward();
    msleep(3000);
    //Turn back to the start box
    //Back up to leave game pieces in the start box.
    //Move around game pieces to get back to the other side of the start box.
    //Repeat original run but closer to buildings (to collect people).
    printf("This will work because Yehoshua is good at coding!\n");
    create_disconnect();
    return 0;
}
