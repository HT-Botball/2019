#include <kipr/botball.h>

// DO NOT move servo #3 less than 675 or more than 1025!!!!

void forward()
{
	motor(1,-100);
	motor(0,100);
}

void right()
{
    motor(1,100);
    motor(0,0);
    msleep(870);
}

void left()
{
    motor(0,100);
    motor(1,0);
    msleep(1150);
}

void backward()
{
    motor(0,-100);
    motor(1,100);
}

int main()
{

    //wait_for_light(0);
    //shut_down_in(120);
    enable_servos();
    //set_servo_position(0,2047);
    //set_servo_position(2,1000);
    //msleep(300);
    forward();
    msleep(3300);
    left();
    while (digital(0)!=1 && digital(1)!=1)
    {
        backward();
        msleep(50);
    }
      while (analog(1)<2500)
    {
        right();
        forward();
        msleep(25);
        left();
        backward();
        msleep(100);
    }
        while (digital(0)!=1 && digital(1)!=1)
    {
        backward();
        msleep(50);
    }
    set_servo_position(2,400);
    forward();
    msleep(3000);
    msleep(1000);
    set_servo_position(0,1000);
    msleep(400);
    forward();
    msleep(300);
	set_servo_position(0,2047);
    msleep(400);
    return 0;
}
